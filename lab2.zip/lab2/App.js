import React from 'react';
import { View, Text, StyleSheet, ImageBackground } from 'react-native';

const App = () => {
  return (
    <ImageBackground
      source={{ uri: 'https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExZDhkMzJvNGNwYWt5bWUycjMybXVwaHdwaDk2MDM0cno0NTVyYXp6YiZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/cmegx6SssTKmEFEcwj/giphy.gif' }} // light pastel gradient background
      style={styles.background}
    >
      <View style={styles.card}>
        <Text style={styles.emoji}>🧑‍💻</Text>
        <Text style={styles.name}>Alex de Rueda</Text>
        <Text style={styles.subinfo}>24 • BS Computer Science / 3-3</Text>

        <View style={styles.divider} />

        <Text style={styles.sectionTitle}>💬 About Me</Text>
        <Text style={styles.info}>Just trying to survive one deadline at a time.</Text>

        <Text style={styles.sectionTitle}>🏆 Achievements</Text>
        <Text style={styles.info}>
          • Discovered that crying *does* fix code sometimes{'\n'}
          • Turning assignments in at 11:59 PM
        </Text>

        <Text style={styles.sectionTitle}>⚡ Skills</Text>
        <Text style={styles.info}>Canva ✨ Figma 🎨 Blender 3D 🧱 and sculpting clay (for when digital art isn't enough chaos).</Text>

        <View style={styles.divider} />

        <Text style={styles.footer}>ID: 202303891 • Valid for 1 Semester </Text>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E3FDFD',
  },
  card: {
    backgroundColor: '#fff',
    width: '85%',
    borderRadius: 25,
    padding: 25,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 5,
    elevation: 5,
  },
  emoji: {
    fontSize: 60,
    marginBottom: 10,
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
  },
  subinfo: {
    fontSize: 14,
    color: '#666',
    marginBottom: 15,
    textAlign: 'center',
  },
  divider: {
    height: 1,
    backgroundColor: '#eee',
    width: '90%',
    marginVertical: 10,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#6A5ACD', // cute lavender accent
    marginTop: 8,
    marginBottom: 3,
    alignSelf: 'flex-start',
  },
  info: {
    fontSize: 15,
    color: '#444',
    marginBottom: 10,
    alignSelf: 'flex-start',
  },
  footer: {
    fontSize: 12,
    color: '#888',
    marginTop: 10,
    fontStyle: 'italic',
  },
});

export default App;
